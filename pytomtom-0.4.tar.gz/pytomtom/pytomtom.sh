cd bin && python '../share/pytomtom/src/pytomtom.py'
