#!/usr/bin/python



from Tkinter import *
import urllib2
import subprocess
import shutil
import tkMessageBox as Msg

#chipsetglobalLocate
def getFileCgl():
    urlfichier = "http://home.tomtom.com/download/Ephemeris.cab?type=ephemeris&amp;eeProvider=globalLocate&amp;devicecode=1"
    req = urllib2.Request(urlfichier, None)
    vid = urllib2.urlopen(req)
    #on cree le fichier en mode donnees de type binaire
    file = open("tmpcgl.cab" , "w+b")
    #on recupere la taille du fichier
    lg = vid.headers.get('content-length')
    # on la convertit en entier
    #lg = int(lg)
    # "buffer"
    data = ''
    #tant que ...
    while True :
        #lire les 4096 octet suivant
        data = vid.read(4096)
        #... le buffer n'est pas null apres une lecture
        if not data: break
        #on ecrit les donnees dans le ffichier
        file.write(data)
        #on vide le buffer
        data = None
    #on finalise l'ecriture
    file.flush()
    #on ferme le fichier
    file.close()
    #on decompresse le cab
    subprocess.call(["cabextract tmpcgl.cab"],shell=True)
    #on deplace le fichier dans une autre destination /media/INTERNAL/ephem/
    shutil.move("lto.dat","/media/INTERNAL/ephem/lto.dat")
    shutil.move("ee_meta.txt","/media/INTERNAL/ephem/ee_meta.txt")
    Msg.showinfo(title="",message="MAJ ok !")

#chipsetSiRFStarIII
def getFileCsi():
    urlfichier = "http://home.tomtom.com/download/Ephemeris.cab?type=ephemeris&amp;eeProvider=SiRFStarIII&amp;devicecode=2"
    req = urllib2.Request(urlfichier, None)
    vid = urllib2.urlopen(req)
    #on cree le fichier en mode donnees de type binaire
    file = open("tmpcsi.cab" , "w+b")
    #on recupere la taille du fichier
    lg = vid.headers.get('content-length')
    # on la convertit en entier
    #lg = int(lg)
    # "buffer"
    data = ''
    #tant que ...
    while True :
        #lire les 4096 octet suivant
        data = vid.read(4096)
        #... le buffer n'est pas null apres une lecture
        if not data: break
        #on ecrit les donnees dans le ffichier
        file.write(data)
        #on vide le buffer
        data = None
    #on finalise l'ecriture
    file.flush()
    #on ferme le fichier
    file.close()
    #on decompresse le cab
    subprocess.call(["cabextract tmpcsi.cab"],shell=True)
    #on deplace le fichier dans une autre destination /media/INTERNAL/ephem/
    shutil.move("packedephemeris.ee","/media/INTERNAL/ephem/packedephemeris.ee")
    shutil.move("ee_meta.txt","/media/INTERNAL/ephem/ee_meta.txt")
    Msg.showinfo(title="",message="MAJ ok !")



#---------------------------------------------------------------------------------
root = Tk()
root.title("pyTOMTOM")

def about():
    fenabout=Toplevel()
    fenabout.grab_set()
    fenabout.focus_set()
    msg=Label(fenabout, text = 'pyTOMTOM version 0.0f', padx =10, pady =5)
    msg.pack()
    msg2=Label(fenabout, text = 'par Thomas LEROY', padx =10, pady =5)
    msg2.pack()
    msg3=Label(fenabout, text = 'tsly_mdk@yahoo.fr', padx =10, pady =5)
    msg3.pack()
    exit=Button(fenabout,text='Fermer', padx =10, pady =5, command=fenabout.destroy)
    exit.pack()

# creation de widgets Label(), et button() :
Label(root, text = '---------------pyTOMTOM ----------------------------------------------', padx =10, pady =5).grid(sticky =N)

# choix chipset
#texte = StringVar()
#def selection():
#	affichage['text'] = texte.get()
#choix1 = Radiobutton(root, text='Chipset SirfStar III', variable=texte, value='csi',
#command=selection)
#choix2 = Radiobutton(root, text='Chipset GlobalLocate', variable=texte, value='cgl',
#command=selection)
#affichage = Label(root)
#choix1.grid()
#choix2.grid()
#affichage.grid()

# boutons
Label(root, text = '''Assurez-vous que votre GPS soit accessible 
au point de montage /media/INTERNAL
et choisissez votre chipset :''', padx =10, pady =5).grid(sticky =N)
bou1 = Button(root, text='GPSQuickfix pour chipset GlobalLocate', command = getFileCgl).grid(sticky =N)
bou4 = Button(root, text='GPSQuickfix pour chipset SirfStar III', command = getFileCsi).grid(sticky =N)
#verif1=Label(root, text='faites un choix', bg="#4c4c4c", fg="#e5c95b").grid(sticky =N)
Label(root, text = '----------------------------------------------------------------------', padx =10, pady =5).grid(sticky =N)
bou2 = Button(root, text='A propos de l\'auteur', command = about).grid()
bou3 = Button(root, text='Quitter', command = root.destroy).grid()
Label(root, text = 'N\'oubliez pas d\'ejecter proprement votre TomTom !', padx =10, pady =5).grid(sticky =N)

# creation d'un widget 'Canvas' contenant une image bitmap :
can1 = Canvas(root, width =200, height =160, bg ='white')
photo = PhotoImage(file ='pytomtom.gif')
can1.create_image(100,80, image =photo)
can1.grid(row =1, column =2, rowspan =6, padx =10, pady =5)

# demarrage :
root.mainloop()