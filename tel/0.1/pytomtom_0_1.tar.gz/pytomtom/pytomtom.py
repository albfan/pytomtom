#/usr/bin/python
# -*- coding:utf-8 -*-
#
# pyTomTom version 0.1 (26 novembre 2009)
#
# auteur : Thomas LEROY
# http://tomonweb.2kool4u.net/pytomtom/
#

import pygtk
pygtk.require('2.0')
import gtk

import urllib2
import subprocess
import shutil
#import tkMessageBox as Msg


class UI:
    def __init__(self):
        self.fenetre = gtk.Window(gtk.WINDOW_TOPLEVEL)
# titre de la fen�tre
	self.fenetre.set_title("pyTomTom")
# taille de la fen�tre
	#self.fenetre.set_size_request(600,300)
# bordure interieure de la fen�tre 
	self.fenetre.set_border_width(10)
# centrage de la fen�tre 
	self.fenetre.set_position(gtk.WIN_POS_CENTER)
	
# -----------------------------------------------------------------
# on crée une boite pour contenir les widgets
	vbox = gtk.VBox(False, 10)
	self.fenetre.add(vbox)
	vbox.show()
	
# image	
	image = gtk.Image()
	image.set_from_file("pytomtom.png")
	vbox.pack_start(image, True, False, 2)

# label
        label = gtk.Label('''Assurez-vous que votre GPS soit accessible 
au point de montage /media/INTERNAL
et choisissez votre chipset :''')
# On centre le texte
	label.set_justify(gtk.JUSTIFY_CENTER)

        vbox.pack_start(label, False, False, 2)

# separator
        hs = gtk.HSeparator()
        vbox.pack_start(hs, False, False, 2)
	
#mon bouton
	btn_cgl = gtk.Button("GPSQuickfix pour chipset GlobalLocate")
	vbox.pack_start(btn_cgl, False, False, 2)
# On connecte le signal "clicked" du bouton a la fonction de controle
        btn_cgl.connect("clicked", self.getFileCgl)
	
#mon bouton
	btn_csi = gtk.Button("GPSQuickfix pour chipset SirfStar III")
	vbox.pack_start(btn_csi, False, False, 2)
# On connecte le signal "clicked" du bouton a la fonction de controle
        #btn_csi.connect("clicked", self.btn_clicked)
	btn_csi.connect("clicked", self.getFileCsi)
	
# separator
        hs = gtk.HSeparator()
        vbox.pack_start(hs, False, False, 2)

# bouton quitter
        b = gtk.Button(stock = gtk.STOCK_QUIT)
        vbox.pack_start(b, False, False, 2)
        b.connect("clicked", self.end)
	
# label
        label = gtk.Label("N\'oubliez pas d\'éjecter proprement votre TomTom !")
        vbox.pack_start(label, False, False, 2)
	
	# label
        label = gtk.Label(".:: pyTomTom version 0.1 ::.")
        vbox.pack_start(label, False, False, 2)

	self.fenetre.show_all()
	self.fenetre.connect("destroy", self.end)

# -----------------------------------------------------------------
# fonctions pour controler
    def btn_clicked(self, widget):
        print widget.get_label()
    def btn_choix1(self, widget):
        print "GPSQuickfix pour chipset GlobalLocate"
    def btn_choix2(self, widget):
        print "GPSQuickfix pour chipset SirfStar III"
#------------------------------------------------------------------

# vraies fonctions du programme pour le choix du chipset

#chipsetglobalLocate
    def getFileCgl(self, widget):
	print widget.get_label()
	urlfichier = "http://home.tomtom.com/download/Ephemeris.cab?type=ephemeris&amp;eeProvider=globalLocate&amp;devicecode=1"
	req = urllib2.Request(urlfichier, None)
	vid = urllib2.urlopen(req)
	#on cree le fichier en mode donnees de type binaire
	file = open("tmpcgl.cab" , "w+b")
	#on recupere la taille du fichier
	lg = vid.headers.get('content-length')
	# on la convertit en entier
	#lg = int(lg)
	# "buffer"
	data = ''
	#tant que ...
	while True :
		#lire les 4096 octet suivant
		data = vid.read(4096)
		#... le buffer n'est pas null apres une lecture
		if not data: break
		#on ecrit les donnees dans le ffichier
		file.write(data)
		#on vide le buffer
		data = None
	#on finalise l'ecriture
	file.flush()
	#on ferme le fichier
	file.close()
	#on decompresse le cab
	subprocess.call(["cabextract tmpcgl.cab"],shell=True)
	#on deplace le fichier dans une autre destination /media/INTERNAL/ephem/
	shutil.move("lto.dat","/media/INTERNAL/ephem/lto.dat")
	shutil.move("ee_meta.txt","/media/INTERNAL/ephem/ee_meta.txt")
	#Msg.showinfo(title="",message=" ")
	
#chipsetSiRFStarIII
    def getFileCsi(self, widget):
	urlfichier = "http://home.tomtom.com/download/Ephemeris.cab?type=ephemeris&amp;eeProvider=SiRFStarIII&amp;devicecode=2"
	req = urllib2.Request(urlfichier, None)
	vid = urllib2.urlopen(req)
	#on cree le fichier en mode donnees de type binaire
	file = open("tmpcsi.cab" , "w+b")
	#on recupere la taille du fichier
	lg = vid.headers.get('content-length')
	# on la convertit en entier
	#lg = int(lg)
	# "buffer"
	data = ''
	#tant que ...
	while True :
		#lire les 4096 octet suivant
		data = vid.read(4096)
		#... le buffer n'est pas null apres une lecture
		if not data: break
		#on ecrit les donnees dans le ffichier
		file.write(data)
		#on vide le buffer
		data = None
	#on finalise l'ecriture
	file.flush()
	#on ferme le fichier
	file.close()
	#on decompresse le cab
	subprocess.call(["cabextract tmpcsi.cab"],shell=True)
	#on deplace le fichier dans une autre destination /media/INTERNAL/ephem/
	shutil.move("packedephemeris.ee","/media/INTERNAL/ephem/packedephemeris.ee")
	shutil.move("ee_meta.txt","/media/INTERNAL/ephem/ee_meta.txt")
	#Msg.showinfo(title="",message=" ")

    def end(self, fenetre):
        gtk.main_quit()

    def main(self):
        gtk.main()


if __name__ == "__main__":
    ui = UI()
    ui.main()
