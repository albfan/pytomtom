#/usr/bin/python
# -*- coding:utf-8 -*-
#
# pyTomTom version 0.2 (decembre 2009)
#
# auteur : Thomas LEROY
#
# remerciements à Philippe (toto740), sunil, chamalow
#
# http://tomonweb.2kool4u.net/pytomtom/
#

import pygtk
pygtk.require('2.0')
import gtk

import urllib2
import subprocess
import shutil


class Notebooktomtom:

    def create_custom_tab(self, text, notebook, frame):

	#On crée une eventbox
        eventBox = gtk.EventBox()
	#On crée une boite horizontale
        tabBox = gtk.HBox(False, 2)
	#On crée un label "text" (text donné en attribut)
        tabLabel = gtk.Label(text)
                
        eventBox.show()
       # tabButton.show()
        tabLabel.show()
	#On attache label
        tabBox.pack_start(tabLabel, False)       

        tabBox.show_all()
	#On ajoute la boite à l'eventbox
        eventBox.add(tabBox)
        return eventBox

#-----------------------------------------------------------------------------------------------------------------------------   
    def delete(self, widget, event=None):
        gtk.main_quit()
        return False
#----------------------------------------------------------------------------------------------------------------------------- 
        #On crée la fenetre principale
    def __init__(self):
        self.fenetre = gtk.Window(gtk.WINDOW_TOPLEVEL)
        self.fenetre.connect("delete_event", self.delete)
        self.fenetre.set_border_width(10)
	#self.fenetre.set_size_request(600,300)
	self.fenetre.set_title("pyTomTom")
	# centrage de la fenetre 
	self.fenetre.set_position(gtk.WIN_POS_CENTER)
	#gtk.status_icon_new_from_file("icon_pytomtom.png")
#-----------------------------------------------------------------------------------------------------------------------------

        #On crée un nouveau notebook
        notebook = gtk.Notebook()
        self.fenetre.add(notebook)
        notebook.show()

#-----------------------------------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------

	#--------------------------------------
	# Onglet OPTIONS
	#--------------------------------------
        frame = gtk.Frame("Options")
        frame.set_border_width(10)
        frame.show()
	
	#On crée une boite horizontale
        tabBox = gtk.VBox(False, 2)	
        frame.add(tabBox)
        tabBox.show()

        label = gtk.Label('''Indiquez le point de montage de votre TomTom :
(généralement /media/INTERNAL ou /media/disk)''')
	label.set_justify(gtk.JUSTIFY_CENTER)
        tabBox.pack_start(label, True, False, 2)
	
	#on ouvre le fichier de config pour récupérer les infos
	config = open('pytomtom.cfg','rb')
	#on recupere le point de montage
	ptmontage = config.readline() 
	ptmontage=ptmontage.rstrip()
	str(ptmontage)
	#on recupere le modele
	modele = config.readline()
	modele=modele.rstrip()
	str(modele)
	#on ferme le fichier config
	config.close()
	
	# Creation du GtkEntry
	self.entry = gtk.Entry()
	self.entry.set_text(ptmontage)
	# Insertion du GtkEntry dans la tabBox
	tabBox.pack_start(self.entry, True, False, 0)
	
	espace = gtk.Label(" ")
	tabBox.pack_start(espace, True, False, 2)
	
	self.boitderoul = gtk.combo_box_new_text()
        self.boitderoul.append_text(modele)
	self.boitderoul.append_text('')
	self.boitderoul.append_text('carminat')
        self.boitderoul.append_text('one 1st edition')
        self.boitderoul.append_text('one 3rd edition')
	self.boitderoul.append_text('one 30 series')
	self.boitderoul.append_text('one XL IQ Routes')
        #self.boitderoul.connect('changed', self.OnUpdate) 
        self.boitderoul.set_active(0)
	tabBox.pack_start(self.boitderoul, True, False, 0)
	
	#self.chp_modele = gtk.Label()
	#self.chp_modele.set_text(modele)
	#tabBox.pack_start(self.chp_modele, True, False, 0)
	
	label = gtk.Label('''La rubrique Documentation sur le site pyTomTom peut vous aider
à identifier le GPS.
Si votre modèle n\'apparait pas dans la liste,
contactez-moi et il sera rajouté avec votre aide...''')
	label.set_justify(gtk.JUSTIFY_CENTER)
        tabBox.pack_start(label, True, False, 2)
	
	button = gtk.Button(stock = gtk.STOCK_SAVE)
	#button = gtk.Button("Enregistrer les options")
	tabBox.pack_start(button, True, False, 0)
	
	#label = gtk.Label()
	#tabBox.pack_start(label, True, False, 0)
	
	# Connexion du signal "activate" du GtkEntry ,app
	#self.entry.connect("activate", self.OnUpdate)
	#self.chp_modele.connect("activate", self.OnUpdate)
	
	# Connexion du signal "clicked" du GtkButton
	button.connect("clicked", self.OnUpdate)
	
        eventBox = self.create_custom_tab("Options", notebook, frame)
        notebook.append_page(frame, eventBox)
	
#-----------------------------------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------
	
	#--------------------------------------
	# Onglet GPSQuickFix
	#--------------------------------------
        frame = gtk.Frame("GPSQuickFix")
        frame.set_border_width(10)
        frame.show()
	
	# on crée une boite pour contenir les widgets
	vbox = gtk.VBox(False, 10)
	frame.add(vbox)
	vbox.show()
	
	# label
        label = gtk.Label('''Assurez-vous d\'avoir correctement paramétré votre GPS
dans l\'onglet options :''')
	# On centre le texte
	label.set_justify(gtk.JUSTIFY_CENTER)
        vbox.pack_start(label, True, False, 2)
	
	#mon bouton
	btn_csi = gtk.Button("Lancer la mise-à-jour GPSQuickfix")
	vbox.pack_start(btn_csi, True, False, 2)
	# On connecte le signal "clicked" du bouton a la fonction de controle
        btn_csi.connect("clicked", self.gpsquickfix)
           
        eventBox = self.create_custom_tab("GPSQuickFix", notebook, frame)
        notebook.append_page(frame, eventBox)
	
#-----------------------------------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------

	#--------------------------------------
	# Onglet SAUVEGARDE
	#--------------------------------------
        frame = gtk.Frame("Sauvegarde et restauration")
        frame.set_border_width(10)
        frame.show()
	
        label = gtk.Label("Wow. Doucement... Je dois aussi dormir la nuit... ;-)")
        frame.add(label)
        label.show()
           
        eventBox = self.create_custom_tab("Sauvegarde", notebook, frame)
        notebook.append_page(frame, eventBox)
	
#-----------------------------------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------

	#--------------------------------------
	# Onglet A PROPOS
	#--------------------------------------
        frame = gtk.Frame("A propos")
        frame.set_border_width(10)
        frame.show()
	
	#On crée une boite horizontale
        tabBox = gtk.VBox(False, 2)	
        frame.add(tabBox)
        tabBox.show()
		
	# image	
	image = gtk.Image()
	image.set_from_file("pytomtom.png")
	tabBox.pack_start(image, True, False, 2)
	
	#On crée un label "text" (text donné en attribut)
        tabLabel = gtk.Label('''version 0.2
	
	http://tomonweb.2kool4u.net/pytomtom/
	''')
	tabLabel.set_justify(gtk.JUSTIFY_CENTER)
	tabLabel.show()
	#On attache label dans la boite
        tabBox.pack_start(tabLabel, True, False, 2)
	
        eventBox = self.create_custom_tab("A propos", notebook, frame)
        notebook.append_page(frame, eventBox)
	
#-----------------------------------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------

	#--------------------------------------
	# Onglet QUITTER
	#--------------------------------------
        frame = gtk.Frame("Quitter ?")
        frame.set_border_width(10)
        #frame.set_size_request(300,150)
        frame.show()
	
	#On crée une boite horizontale
        tabBox = gtk.VBox(False, 2)	
        frame.add(tabBox)
        tabBox.show()
	
	# label
        label = gtk.Label("N\'oubliez pas d\'éjecter proprement votre TomTom !")
       	label.show()
	tabBox.pack_start(label, True, False, 2)
	
	# bouton quitter
        b = gtk.Button(stock = gtk.STOCK_QUIT)
	b.show()
	tabBox.pack_start(b, True, False, 2)
        b.connect("clicked", self.end)
	
           
        eventBox = self.create_custom_tab("Quitter", notebook, frame)
        notebook.append_page(frame, eventBox)
	
#-----------------------------------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------
		    
        # Onglet que nous verrons à l'ouverture (attention à la page 0)
        notebook.set_current_page(3)
	
        self.fenetre.show_all()
	
# -----------------------------------------------------------------
# fonctions pour controler
    def btn_clicked(self, widget):
        print widget.get_label()
    def btn_choix1(self, widget):
        print "GPSQuickfix pour chipset GlobalLocate"
    def btn_choix2(self, widget):
        print "GPSQuickfix pour chipset SirfStar III"
#------------------------------------------------------------------
# vraies fonctions du programme

    def OnUpdate(self,entry):
	
	modele = self.boitderoul.get_model()
        index = self.boitderoul.get_active()
	mod = modele[index][0]
        if index:
            print "TomTom ", mod
       
    # Recuperation du texte contenu dans le GtkEntry
	texte = self.entry.get_text()
	str(texte)
	#mod = self.chp_modele.get_text()
	str(mod)
	fichier = open("pytomtom.cfg", "wb")        #Créer le fichier s'il n'existe pas
	fichier.write(texte)        #Écrit la valeur de la variable a dans le fichier
	fichier.write("\n")
	fichier.write(mod)
	fichier.close()
	
#fonction GPSQuickfix UNIQUE
    def gpsquickfix(self, widget):
	print widget.get_label()
	
	#on ouvre le fichier de config pour récupérer les infos
	config = open('pytomtom.cfg','rb')
	#on recupere le point de montage
	ptmontage = config.readline() 
	ptmontage=ptmontage.rstrip()
	chemin=str(ptmontage+"/ephem")
	print chemin
	#on recupere le modele
	modele = config.readline()
	modele=modele.rstrip()
	str(modele)
	print modele
	#on ferme le fichier config
	config.close()
	
	SiRFStarIII = ["carminat", "one 1st edition"]
	globalLocate = ["one 3rd edition", "one 30 series", "XL IQ Routes"]
	if modele in SiRFStarIII: # si le tomtom possede un chipset SiRFStarIII
		print "chipset SiRFStarIII"
		urlfichier = "http://home.tomtom.com/download/Ephemeris.cab?type=ephemeris&amp;eeProvider=SiRFStarIII&amp;devicecode=2"
	else : # sinon (si le tomtom possede un chipset globalLocate)
		print "chipset globalLocate"
		urlfichier = "http://home.tomtom.com/download/Ephemeris.cab?type=ephemeris&amp;eeProvider=globalLocate&amp;devicecode=1"
		
	req = urllib2.Request(urlfichier, None)
	vid = urllib2.urlopen(req)
	#on cree le fichier en mode donnees de type binaire
	file = open("/tmp/gpsquickfix.cab" , "w+b")
	#on recupere la taille du fichier
	lg = vid.headers.get('content-length')
	# on la convertit en entier
	#lg = int(lg)
	# "buffer"
	data = ''
	#tant que ...
	while True :
		#lire les 4096 octet suivant
		data = vid.read(4096)
		#... le buffer n'est pas null apres une lecture
		if not data: break
		#on ecrit les donnees dans le ffichier
		file.write(data)
		#on vide le buffer
		data = None
	#on finalise l'ecriture
	file.flush()
	#on ferme le fichier
	file.close()
	#on decompresse le cab
	subprocess.call(["cabextract -d /tmp /tmp/gpsquickfix.cab"],shell=True)
	
	#on deplace le fichier dans  le dossier ephem shutil.move
	if modele in SiRFStarIII: # si le tomtom possede un chipset SiRFStarIII
		print "chipset SiRFStarIII"
		shutil.copy("/tmp/packedephemeris.ee",chemin)
		shutil.copy("/tmp/ee_meta.txt",chemin)
	else : # sinon (si le tomtom possede un chipset globalLocate)
		print "chipset globalLocate"
		shutil.copy("/tmp/lto.dat",chemin)
		shutil.copy("/tmp/ee_meta.txt",chemin)
	
#------------------------------------------------------------------
	
    def end(self, fenetre):
        gtk.main_quit()

def main():
    gtk.main()
    return 0

if __name__ == "__main__":

    Notebooktomtom()

    main()

