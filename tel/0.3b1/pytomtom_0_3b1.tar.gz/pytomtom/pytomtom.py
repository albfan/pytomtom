#/usr/bin/python
# -*- coding:utf-8 -*-
#
# pyTomTom version 0.3b1 (8 décembre 2009)
#
# auteur : Thomas LEROY
#
# remerciements à Philippe (toto740), sunil, chamalow, exzemat
#
# http://tomonweb.2kool4u.net/pytomtom/
#

import pygtk
pygtk.require('2.0')
import gtk

import urllib2
import subprocess
import shutil


class Notebooktomtom:

    def create_custom_tab(self, text, notebook, frame):

	#On crée une eventbox
        eventBox = gtk.EventBox()
	#On crée une boite horizontale
        tabBox = gtk.HBox(False, 2)
	#On crée un label "text" (text donné en attribut)
        tabLabel = gtk.Label(text)
                
        eventBox.show()
        tabLabel.show()
	#On attache tablabel
        tabBox.pack_start(tabLabel, False)       

        tabBox.show_all()
	#On ajoute la boite à l'eventbox
        eventBox.add(tabBox)
        return eventBox

#-----------------------------------------------------------------------------------------------------------------------------   
    def delete(self, widget, event=None):
        gtk.main_quit()
        return False
#----------------------------------------------------------------------------------------------------------------------------- 
        #On crée la fenetre principale
    def __init__(self):
        self.fenetre = gtk.Window(gtk.WINDOW_TOPLEVEL)
        self.fenetre.connect("delete_event", self.delete)
        self.fenetre.set_border_width(10)
	#self.fenetre.set_size_request(600,300)
	self.fenetre.set_title("pyTomTom")
	# centrage de la fenetre 
	self.fenetre.set_position(gtk.WIN_POS_CENTER)
	#gtk.status_icon_new_from_file("icon_pytomtom.png")
#-----------------------------------------------------------------------------------------------------------------------------

        #On crée un nouveau notebook
        notebook = gtk.Notebook()
        self.fenetre.add(notebook)
        notebook.show()

#-----------------------------------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------

	#--------------------------------------
	# Onglet OPTIONS
	#--------------------------------------
        frame = gtk.Frame("Options")
        frame.set_border_width(10)
        frame.show()
	
	#On crée une boite horizontale
        tabBox = gtk.VBox(False, 2)	
        frame.add(tabBox)
        tabBox.show()

        label = gtk.Label('''Indiquez le point de montage de votre TomTom :
(généralement /media/INTERNAL ou /media/disk)''')
	label.set_justify(gtk.JUSTIFY_CENTER)
        tabBox.pack_start(label, True, False, 2)
	
	#on ouvre le fichier de config pour récupérer les infos
	config = open('pytomtom.cfg','rb')
	#on recupere le point de montage
	ptmontage = config.readline() 
	ptmontage=ptmontage.rstrip()
	str(ptmontage)
	#on recupere le modele
	modele = config.readline()
	modele=modele.rstrip()
	str(modele)
	#on ferme le fichier config
	config.close()
	
	# bouton parcourir
        p = gtk.Button("Sélectionner le point de montage du TomTom...")
	tabBox.pack_start(p, True, False, 2)
        p.connect("clicked", self.parcourir_gps)
	#label affichage point de montage
	self.label = gtk.Label(ptmontage)
	self.label.set_justify(gtk.JUSTIFY_CENTER)
        tabBox.pack_start(self.label, True, False, 2)
		
	# separator
        hs = gtk.HSeparator()
        tabBox.pack_start(hs, False, False, 2)
	
	#espace = gtk.Label(" ")
	#tabBox.pack_start(espace, True, False, 2)
	
	self.boitderoul = gtk.combo_box_new_text()
        self.boitderoul.append_text(modele)
	self.boitderoul.append_text('')
	self.boitderoul.append_text('Carminat')
	self.boitderoul.append_text('GO 510 - 710 - 910')
	self.boitderoul.append_text('GO 520 - 720 - 920 T')
	self.boitderoul.append_text('GO 530 - 630 - 730 - 930 T')
	self.boitderoul.append_text('GO 740 Live - 940 Live')
	self.boitderoul.append_text('GO 750 Live - 950 Live')
	self.boitderoul.append_text('One 1st edition')
	self.boitderoul.append_text('One 3rd edition')
	self.boitderoul.append_text('One 30 Series - New One 2008 - One v4')
	self.boitderoul.append_text('One IQ Routes')
	self.boitderoul.append_text('One XL')
	self.boitderoul.append_text('One XL 2008')
	self.boitderoul.append_text('One XL IQ Routes')
	self.boitderoul.append_text('One XL Live')
	self.boitderoul.append_text('Rider')
	self.boitderoul.append_text('Rider 2nd edition')
	self.boitderoul.append_text('Start')
        #self.boitderoul.connect('changed', self.OnUpdate) 
        self.boitderoul.set_active(0)
	tabBox.pack_start(self.boitderoul, True, False, 0)
	
	label = gtk.Label('''La rubrique Documentation sur le site pyTomTom peut vous aider
à identifier le GPS.
Si votre modèle n\'apparait pas dans la liste,
contactez-moi et il sera rajouté avec votre aide...''')
	label.set_justify(gtk.JUSTIFY_CENTER)
        tabBox.pack_start(label, True, False, 2)
	
	# separator
        hs = gtk.HSeparator()
        tabBox.pack_start(hs, True, False, 2)
	
	button = gtk.Button(stock = gtk.STOCK_SAVE)
	#button = gtk.Button("Enregistrer les options")
	tabBox.pack_start(button, True, False, 0)
	
	#label = gtk.Label()
	#tabBox.pack_start(label, True, False, 0)
	
	# Connexion du signal "activate" du GtkEntry ,app
	#self.entry.connect("activate", self.OnUpdate)
	#self.chp_modele.connect("activate", self.OnUpdate)
	
	# Connexion du signal "clicked" du GtkButton
	button.connect("clicked", self.OnUpdate)
	
        eventBox = self.create_custom_tab("Options", notebook, frame)
        notebook.append_page(frame, eventBox)
	
#-----------------------------------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------
	
	#--------------------------------------
	# Onglet GPSQuickFix
	#--------------------------------------
        frame = gtk.Frame("GPSQuickFix")
        frame.set_border_width(10)
        frame.show()
	
	# on crée une boite pour contenir les widgets
	vbox = gtk.VBox(False, 10)
	frame.add(vbox)
	vbox.show()
	
	# label
        label = gtk.Label('''Assurez-vous d\'avoir correctement paramétré votre GPS
dans l\'onglet options :''')
	# On centre le texte
	label.set_justify(gtk.JUSTIFY_CENTER)
        vbox.pack_start(label, True, False, 2)
	
	# bouton maj quickfix
	btn_csi = gtk.Button("Lancer la mise-à-jour GPSQuickfix")
	vbox.pack_start(btn_csi, True, False, 2)
	# On connecte le signal "clicked" du bouton a la fonction qui lui correspond
        btn_csi.connect("clicked", self.gpsquickfix)
           
        eventBox = self.create_custom_tab("GPSQuickFix", notebook, frame)
        notebook.append_page(frame, eventBox)
	
#-----------------------------------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------

	#---------------------------------------------------------------------
	# Onglet SAUVEGARDE ET RESTAURATION
	#---------------------------------------------------------------------
	
	frame = gtk.Frame("Sauvegarde et restauration")
        frame.set_border_width(10)
        frame.show()
	
	# on crée une boite pour contenir les widgets
	vbox = gtk.VBox(False, 10)
	frame.add(vbox)
	vbox.show()
	
	label = gtk.Label(" ")
	label.set_justify(gtk.JUSTIFY_CENTER)
        vbox.pack_start(label, True, False, 2)
	
        label = gtk.Label('''Pendant ces opérations, pyTomTom peut ne plus répondre. 
La fenêtre se grise pendant plusieurs minutes...
Pour info, 25 minutes et 1GB sur le disque dur pour un One Series 30''')
	label.set_justify(gtk.JUSTIFY_CENTER)
        vbox.pack_start(label, True, False, 2)
	
	# separator
        hs = gtk.HSeparator()
        vbox.pack_start(hs, True, False, 2)
	
	label = gtk.Label('''Le fichier de sauvegarde sera créé dans votre dossier HOME
et se nommera \"sauvegarde_TOMTOM.tar\"''')
	label.set_justify(gtk.JUSTIFY_CENTER)
        vbox.pack_start(label, True, False, 2)
	
	# bouton sauvegarde
	btn_sauvegarde = gtk.Button("Lancer la sauvegarde...")
	vbox.pack_start(btn_sauvegarde, True, False, 2)
	# On connecte le signal "clicked" du bouton a la fonction qui lui correspond
        btn_sauvegarde.connect("clicked", self.sauvegarde_gps)
	
	# separator
        hs = gtk.HSeparator()
        vbox.pack_start(hs, True, False, 2)
	
	label = gtk.Label('''Le fichier de restauration \"sauvegarde_TOMTOM.tar\" 
doit se trouver dans votre dossier HOME''')
	label.set_justify(gtk.JUSTIFY_CENTER)
	label.set_sensitive(False)
        vbox.pack_start(label, True, False, 2)
	
	# bouton RESTAURATION
	btn_restauration = gtk.Button("Lancer la restauration...")
	btn_restauration.set_sensitive(False)
	vbox.pack_start(btn_restauration, True, False, 2)
	# On connecte le signal "clicked" du bouton a la fonction qui lui correspond
        btn_restauration.connect("clicked", self.restauration_gps)
	
	label = gtk.Label('''N\'utilisez la restauration qu\'en cas d\'absolue nécessité !''')
	label.set_justify(gtk.JUSTIFY_CENTER)
	label.set_sensitive(False)
        vbox.pack_start(label, True, False, 2)
           
        eventBox = self.create_custom_tab("Sauvegarde", notebook, frame)
        notebook.append_page(frame, eventBox)
	
#-----------------------------------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------

	#--------------------------------------
	# Onglet BONUS
	#--------------------------------------
        frame = gtk.Frame("Personnaliser son GPS")
        frame.set_border_width(10)
        #frame.set_size_request(300,150)
        frame.show()
	#On crée une boite horizontale
        tabBox = gtk.VBox(False, 2)	
        frame.add(tabBox)
        tabBox.show()
	
	# label
        label = gtk.Label("Remplacez l\'écran de démarrage de votre GPS par la photo de votre choix")
       	tabBox.pack_start(label, True, False, 2)
	# subprocess.call(["convert image.jpg -resize 320x240 -background black -gravity center -extent 320x240 splash.bmp"],shell=True)
	# bouton 
        b = gtk.Button("texte bouton")
	tabBox.pack_start(b, True, False, 2)
        b.connect("clicked", self.end)
	
           
        eventBox = self.create_custom_tab("Bonus", notebook, frame)
        #notebook.append_page(frame, eventBox)
	
#-----------------------------------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------

	#--------------------------------------
	# Onglet A PROPOS
	#--------------------------------------
        frame = gtk.Frame("A propos")
        frame.set_border_width(10)
        frame.show()
	
	#On crée une boite horizontale
        tabBox = gtk.VBox(False, 2)	
        frame.add(tabBox)
        tabBox.show()
		
	# image	
	image = gtk.Image()
	image.set_from_file("pytomtom.png")
	tabBox.pack_start(image, True, False, 2)
	
	#On crée un label "text" (text donné en attribut)
        tabLabel = gtk.Label('''version 0.3b1
	
	http://tomonweb.2kool4u.net/pytomtom/
	''')
	tabLabel.set_justify(gtk.JUSTIFY_CENTER)
	tabLabel.show()
	#On attache label dans la boite
        tabBox.pack_start(tabLabel, True, False, 2)
	
	
	#on ouvre le fichier de config pour récupérer les infos
	config = open('pytomtom.cfg','rb')
	#on recupere les infos
	infos = config.readlines() 
	#infos=ptmontage.rstrip()
	str(infos)
	#on ferme le fichier config
	config.close()
	print "pytomtom 0.3b1"
	print infos
	
        eventBox = self.create_custom_tab("A propos", notebook, frame)
        notebook.append_page(frame, eventBox)
	
#-----------------------------------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------

	#--------------------------------------
	# Onglet QUITTER
	#--------------------------------------
        frame = gtk.Frame("Quitter ?")
        frame.set_border_width(10)
        #frame.set_size_request(300,150)
        frame.show()
	
	#On crée une boite horizontale
        tabBox = gtk.VBox(False, 2)	
        frame.add(tabBox)
        tabBox.show()
	
	# label
        label = gtk.Label("N\'oubliez pas d\'éjecter proprement votre TomTom !")
       	label.show()
	tabBox.pack_start(label, True, False, 2)
	
	# bouton quitter
        b = gtk.Button(stock = gtk.STOCK_QUIT)
	b.show()
	tabBox.pack_start(b, True, False, 2)
        b.connect("clicked", self.end)
	
           
        eventBox = self.create_custom_tab("Quitter", notebook, frame)
        notebook.append_page(frame, eventBox)
	
#-----------------------------------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------
	# Onglet que nous verrons à l'ouverture (attention à la page 0)
        notebook.set_current_page(3)
	
        self.fenetre.show_all()
# -----------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------

	#--------------------------------------
	# LES FONCTIONS
	#--------------------------------------
# -----------------------------------------------------------------
# fonctions temporaires pour controler (debug)
#
    def btn_clicked(self, widget):
        print widget.get_label()
    def btn_choix1(self, widget):
        print "GPSQuickfix pour chipset GlobalLocate"
    def btn_choix2(self, widget):
        print "GPSQuickfix pour chipset SirfStar III"
#------------------------------------------------------------------
#------------------------------------------------------------------
# fonction parcourir le point de montage
#
    def parcourir_gps(self,entry):
	
	self.window = gtk.FileChooserDialog("Ouvrir...", gtk.Window(gtk.WINDOW_TOPLEVEL), gtk.FILE_CHOOSER_ACTION_SELECT_FOLDER, (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_OPEN, gtk.RESPONSE_OK));

	if(self.window.run() == gtk.RESPONSE_OK):
		dossier = self.window.get_filename()
		print dossier
		self.label.set_text(dossier)
		self.window.destroy()
		
#------------------------------------------------------------------
#------------------------------------------------------------------
# fonction enregistrer les paramètres dans un fichier config
#
    def OnUpdate(self,entry):
	
	# Recuperation des differents paramètres
	modele = self.boitderoul.get_model()
        index = self.boitderoul.get_active()
	mod = modele[index][0]
	str(mod)
	ptmontage = self.label.get_text()
	str(ptmontage)
	
	fichier = open("pytomtom.cfg", "wb")
	#Écrit la valeur de la variable ptmontage et mod dans le fichier
	fichier.write(ptmontage)        
	fichier.write("\n")
	fichier.write(mod)
	fichier.close()
	
	print "TomTom ", mod, "::enregistré::"
	print ptmontage, "::enregistré::"
#------------------------------------------------------------------
#------------------------------------------------------------------
# fonction GPSQUICKFIX
#
    def gpsquickfix(self, widget):
	print widget.get_label()
	
	#on ouvre le fichier de config pour récupérer les infos
	config = open('pytomtom.cfg','rb')
	#on recupere le point de montage
	ptmontage = config.readline() 
	ptmontage=ptmontage.rstrip()
	chemin=str(ptmontage+"/ephem")
	print chemin
	#on recupere le modele
	modele = config.readline()
	modele=modele.rstrip()
	str(modele)
	print modele
	#on ferme le fichier config
	config.close()
	
	#on liste d'un coté les chipset sirfstarIII et de l'autre les GlobalLocate
	SiRFStarIII = ["Carminat","GO 510 - 710 - 910","GO 520 - 720 - 920 T","GO 530 - 630 - 730 - 930 T","One 1st edition","Rider","Rider 2nd edition"]
	globalLocate = ["GO 740 Live - 940 Live","GO 750 Live - 950 Live","One 3rd edition","One 30 Series - New One 2008 - One v4","One IQ Routes","One XL","One XL 2008","One XL IQ Routes","One XL Live","Start"]
	if modele in SiRFStarIII: # si le tomtom possede un chipset SiRFStarIII
		print "chipset SiRFStarIII"
		urlfichier = "http://home.tomtom.com/download/Ephemeris.cab?type=ephemeris&amp;eeProvider=SiRFStarIII&amp;devicecode=2"
	else : # sinon (si le tomtom possede un chipset globalLocate)
		print "chipset globalLocate"
		urlfichier = "http://home.tomtom.com/download/Ephemeris.cab?type=ephemeris&amp;eeProvider=globalLocate&amp;devicecode=1"
		
	req = urllib2.Request(urlfichier, None)
	vid = urllib2.urlopen(req)
	#on cree le fichier en mode donnees de type binaire
	file = open("/tmp/gpsquickfix.cab" , "w+b")
	#on recupere la taille du fichier
	lg = vid.headers.get('content-length')
	# on la convertit en entier
	#lg = int(lg)
	# "buffer"
	data = ''
	#tant que ...
	while True :
		#lire les 4096 octet suivant
		data = vid.read(4096)
		#... le buffer n'est pas null apres une lecture
		if not data: break
		#on ecrit les donnees dans le ffichier
		file.write(data)
		#on vide le buffer
		data = None
	#on finalise l'ecriture
	file.flush()
	#on ferme le fichier
	file.close()
	#on decompresse le cab
	subprocess.call(["cabextract -d /tmp /tmp/gpsquickfix.cab"],shell=True)
	
	#on copie les fichiers dans  le dossier ephem
	if modele in SiRFStarIII: # si le tomtom possede un chipset SiRFStarIII
		print "chipset SiRFStarIII"
		shutil.copy("/tmp/packedephemeris.ee",chemin)
		shutil.copy("/tmp/ee_meta.txt",chemin)
	else : # sinon (si le tomtom possede un chipset globalLocate)
		print "chipset globalLocate"
		shutil.copy("/tmp/lto.dat",chemin)
		shutil.copy("/tmp/ee_meta.txt",chemin)
#------------------------------------------------------------------
#------------------------------------------------------------------
# fonction SAUVEGARDE
#
    def sauvegarde_gps(self, widget):
	# tmp_zip='pictures_'+strftime("%d%b%Y_%H%M%S",localtime())+'.zip'
	#
	# on ouvre le fichier de config pour récupérer les infos
	config = open('pytomtom.cfg','rb')
	# on recupere le point de montage
	ptmontage = config.readline() 
	ptmontage=ptmontage.rstrip()
	str(ptmontage)
	# on ferme le fichier config
	config.close()
	commande = "cd "+ptmontage+" && tar -cf ~/sauvegarde_TOMTOM.tar ."
	str(commande)
	print commande
	print "debut de sauvegarde"
	subprocess.call([commande],shell=True)
	print "fin de sauvegarde"
#
#------------------------------------------------------------------
#------------------------------------------------------------------
# fonction RESTAURATION
#
    def restauration_gps(self, widget):
	
	# on ouvre le fichier de config pour récupérer les infos
	config = open('pytomtom.cfg','rb')
	# on recupere le point de montage
	ptmontage = config.readline() 
	ptmontage=ptmontage.rstrip()
	str(ptmontage)
	# on ferme le fichier config
	config.close()
	commande = "cd "+ptmontage+" && tar -xf ~/sauvegarde_TOMTOM.tar"
	str(commande)
	print commande
	print "debut de restauration"
	subprocess.call([commande],shell=True)
	print "fin de restauration"
#
#------------------------------------------------------------------
	
    def end(self, fenetre):
        gtk.main_quit()

def main():
    gtk.main()
    return 0

if __name__ == "__main__":

    Notebooktomtom()

    main()

